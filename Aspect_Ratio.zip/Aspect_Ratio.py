bl_info = {
    "name": "Advanced Aspect Ratio",
    "author": "Dimona Patrick",
    "version": (1, 3),
    "blender": (3, 0, 0),
    "location": "Properties > Render > Aspect Ratio",
    "description": "Advanced aspect ratio manager with camera overlay and composition guides",
    "category": "Render"
}

import bpy
import gpu
import blf
from gpu_extras.batch import batch_for_shader
from bpy.types import PropertyGroup, Panel, Operator, Menu
from bpy.props import (BoolProperty, FloatProperty, EnumProperty, 
                      PointerProperty, StringProperty)

# Consolidated aspect ratios with categories
ASPECT_RATIOS = [
    # Cinema
    ("CINEMA", "Cinema", [
        ("2.39:1", 2.39, "Anamorphic Widescreen"),
        ("1.85:1", 1.85, "Standard Widescreen"),
        ("1.43:1", 1.43, "IMAX"),
    ]),
    # Photography
    ("PHOTO", "Photography", [
        ("3:2", 1.5, "Standard DSLR"),
        ("4:3", 1.33, "Medium Format"),
        ("1:1", 1.0, "Square Format"),
        ("16:9", 1.77, "HD Video"),
    ]),
    # Social Media
    ("SOCIAL", "Social Media", [
        ("9:16", 0.5625, "Instagram Story/TikTok"),
        ("4:5", 0.8, "Instagram Portrait"),
        ("1:1", 1.0, "Instagram Square"),
        ("16:9", 1.77, "YouTube"),
    ])
]

class AspectRatioSettings(PropertyGroup):
    adjust_width: BoolProperty(
        name="Adjust Width",
        description="Adjust width instead of height when setting aspect ratio",
        default=True
    )
    guide_type: EnumProperty(
        name="Composition Guide",
        description="Type of composition guide to display",
        items=[
            ('NONE', 'None', 'No guides'),
            ('THIRDS', 'Rule of Thirds', 'Display rule of thirds grid'),
            ('GOLDEN', 'Golden Ratio', 'Display golden ratio'),
            ('CENTER', 'Center', 'Display center lines'),
        ],
        default='THIRDS',
        update=lambda self, context: update_camera_guides(self, context)
    )
    category: EnumProperty(
        name="Category",
        items=[(cat[0], cat[1], "") for cat in ASPECT_RATIOS],
        default="CINEMA"
    )

def update_camera_guides(self, context):
    """Update camera display settings based on guide type"""
    if context.scene.camera:
        camera = context.scene.camera.data
        
        # Enable camera view options
        camera.show_composition_thirds = False
        camera.show_composition_golden = False
        camera.show_composition_center = False
        
        # Set the selected guide
        if self.guide_type == 'THIRDS':
            camera.show_composition_thirds = True
        elif self.guide_type == 'GOLDEN':
            camera.show_composition_golden = True
        elif self.guide_type == 'CENTER':
            camera.show_composition_center = True

        # Enable other useful camera displays
        camera.show_composition_grid = True
        camera.show_name = True
        camera.show_passepartout = True
        camera.passepartout_alpha = 1.0




class ASPECT_OT_SetRatio(Operator):
    """Set render resolution aspect ratio"""
    bl_idname = "aspect.set_ratio"
    bl_label = "Set Aspect Ratio"
    
    ratio: FloatProperty()
    name: StringProperty()
    description: StringProperty()  
    
    def execute(self, context):
        scene = context.scene
        settings = scene.aspect_ratio_settings
        render = scene.render

        if settings.adjust_width:
            render.resolution_x = int(render.resolution_y * self.ratio)
        else:
            render.resolution_y = int(render.resolution_x / self.ratio)

        self.report({'INFO'}, f"Set aspect ratio to {self.name}")
        return {'FINISHED'}

class ASPECT_PT_Panel(Panel):
    """Advanced Aspect Ratio Panel"""
    bl_label = "Aspect Ratio"
    bl_idname = "ASPECT_PT_Panel"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        settings = context.scene.aspect_ratio_settings

        # Overlay Settings
        box = layout.box()
        row = box.row()
        row.label(text="Overlay Settings", icon='OVERLAY')
        
        # Create a row for overlay toggles
        row = box.row(align=True)
        row.prop(settings, "show_overlay", icon='RESTRICT_VIEW_OFF')
        row.prop(settings, "show_info", icon='INFO')
        
        # Create a row for other overlay settings
        row = box.row(align=True)
        row.prop(settings, "overlay_opacity")
        row.prop(settings, "guide_type")
        
        # Camera Display Settings (New Section)
        camera = context.scene.camera
        if camera:
            cam_data = camera.data
            
            box = layout.box()
            row = box.row()
            row.label(text="Camera Display", icon='CAMERA_DATA')
            
            col = box.column(align=True)
            col.prop(cam_data, "show_composition_grid", text="Show Grid")
            col.prop(cam_data, "show_name", text="Show Camera Name")
            col.prop(cam_data, "show_passepartout", text="Show Passepartout")
            if cam_data.show_passepartout:
                col.prop(cam_data, "passepartout_alpha", text="Passepartout Opacity")
        
        # Aspect Ratio Selection
        box = layout.box()
        row = box.row()
        row.label(text="Aspect Ratios", icon='CAMERA_DATA')
        row = box.row()
        row.prop(settings, "category", expand=True)
        
        # Display ratios for selected category in rows
        for cat in ASPECT_RATIOS:
            if cat[0] == settings.category:
                ratios = cat[2]
                buttons_per_row = 2
                
                for i in range(0, len(ratios), buttons_per_row):
                    row = box.row(align=True)
                    row_ratios = ratios[i:i + buttons_per_row]
                    
                    for name, ratio, desc in row_ratios:
                        op = row.operator("aspect.set_ratio", text=f"{name}", icon='CAMERA_DATA')
                        op.ratio = ratio
                        op.name = name
                        op.description = desc
                break
        
        # Settings
        box = layout.box()
        row = box.row()
        row.label(text="Settings", icon='PREFERENCES')
        row = box.row()
        row.prop(settings, "adjust_width", icon='ARROW_LEFTRIGHT')

        # Add current resolution info
        box = layout.box()
        row = box.row()
        row.label(text="Current Settings", icon='INFO')
        
        render = context.scene.render
        current_ratio = render.resolution_x / render.resolution_y
        
        col = box.column(align=True)
        row = col.row(align=True)
        row.label(text=f"Resolution: {render.resolution_x} x {render.resolution_y}")
        row = col.row(align=True)
        row.label(text=f"Aspect Ratio: {current_ratio:.3f}:1")


LENS_PRESETS = [
    ("14mm", 14, "Ultra Wide Angle"),
    ("24mm", 24, "Wide Angle"),
    ("35mm", 35, "Standard Wide"),
    ("50mm", 50, "Normal"),
    ("85mm", 85, "Portrait"),
    ("135mm", 135, "Telephoto"),
    ("200mm", 200, "Long Telephoto")
]

class ASPECT_MT_lens_wide_menu(Menu):
    bl_label = "Wide Angle Lenses"
    bl_idname = "ASPECT_MT_lens_wide_menu"

    def draw(self, context):
        layout = self.layout
        for name, focal_length, desc in LENS_PRESETS[:3]:
            op = layout.operator("aspect.set_lens", text=f"{name} - {desc}")
            op.focal_length = focal_length

class ASPECT_MT_lens_tele_menu(Menu):
    bl_label = "Telephoto Lenses"
    bl_idname = "ASPECT_MT_lens_tele_menu"

    def draw(self, context):
        layout = self.layout
        for name, focal_length, desc in LENS_PRESETS[4:]:
            op = layout.operator("aspect.set_lens", text=f"{name} - {desc}")
            op.focal_length = focal_length

class ASPECT_MT_cinema_menu(Menu):
    bl_label = "Cinema Ratios"
    bl_idname = "ASPECT_MT_cinema_menu"

    def draw(self, context):
        layout = self.layout
        for name, ratio, desc in ASPECT_RATIOS[0][2]:
            op = layout.operator("aspect.set_ratio", text=f"{name} - {desc}")
            op.ratio = ratio
            op.name = name
            op.description = desc

class ASPECT_MT_photo_menu(Menu):
    bl_label = "Photo Ratios"
    bl_idname = "ASPECT_MT_photo_menu"

    def draw(self, context):
        layout = self.layout
        for name, ratio, desc in ASPECT_RATIOS[1][2]:
            op = layout.operator("aspect.set_ratio", text=f"{name} - {desc}")
            op.ratio = ratio
            op.name = name
            op.description = desc

class ASPECT_MT_social_menu(Menu):
    bl_label = "Social Media Ratios"
    bl_idname = "ASPECT_MT_social_menu"

    def draw(self, context):
        layout = self.layout
        for name, ratio, desc in ASPECT_RATIOS[2][2]:
            op = layout.operator("aspect.set_ratio", text=f"{name} - {desc}")
            op.ratio = ratio
            op.name = name
            op.description = desc

class ASPECT_MT_pie_menu(Menu):
    bl_label = "Aspect Ratio & Lens"
    bl_idname = "ASPECT_MT_pie_menu"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        
        # Left - Wide Angle Lenses
        pie.menu(ASPECT_MT_lens_wide_menu.bl_idname, 
                text="Wide Angle Lenses", 
                icon='DISCLOSURE_TRI_RIGHT')
            
        # Right - Telephoto Lenses
        pie.menu(ASPECT_MT_lens_tele_menu.bl_idname, 
                text="Telephoto Lenses", 
                icon='DISCLOSURE_TRI_RIGHT')
            
        # Bottom - Cinema Ratios
        pie.menu(ASPECT_MT_cinema_menu.bl_idname, 
                text="Cinema Ratios", 
                icon='DISCLOSURE_TRI_RIGHT')
            
        # Top - Normal Lens
        op = pie.operator("aspect.set_lens", text="50mm - Normal")
        op.focal_length = 50
        
        # Top Left - Photo Ratios
        pie.menu(ASPECT_MT_photo_menu.bl_idname, 
                text="Photo Ratios", 
                icon='DISCLOSURE_TRI_RIGHT')
            
        # Top Right - Social Media Ratios
        pie.menu(ASPECT_MT_social_menu.bl_idname, 
                text="Social Media Ratios", 
                icon='DISCLOSURE_TRI_RIGHT')

# Update the register and unregister functions
def register():
    bpy.utils.register_class(AspectRatioSettings)
    bpy.utils.register_class(ASPECT_OT_SetRatio)
    bpy.utils.register_class(ASPECT_OT_SetLens)
    # Register all menus
    bpy.utils.register_class(ASPECT_MT_lens_wide_menu)
    bpy.utils.register_class(ASPECT_MT_lens_tele_menu)
    bpy.utils.register_class(ASPECT_MT_cinema_menu)
    bpy.utils.register_class(ASPECT_MT_photo_menu)
    bpy.utils.register_class(ASPECT_MT_social_menu)
    bpy.utils.register_class(ASPECT_MT_pie_menu)
    bpy.utils.register_class(ASPECT_PT_Panel)
    bpy.types.Scene.aspect_ratio_settings = PointerProperty(type=AspectRatioSettings)
    register_keymaps()

def unregister():
    unregister_keymaps()
    bpy.utils.unregister_class(ASPECT_PT_Panel)
    # Unregister all menus
    bpy.utils.unregister_class(ASPECT_MT_pie_menu)
    bpy.utils.unregister_class(ASPECT_MT_social_menu)
    bpy.utils.unregister_class(ASPECT_MT_photo_menu)
    bpy.utils.unregister_class(ASPECT_MT_cinema_menu)
    bpy.utils.unregister_class(ASPECT_MT_lens_tele_menu)
    bpy.utils.unregister_class(ASPECT_MT_lens_wide_menu)
    bpy.utils.unregister_class(ASPECT_OT_SetLens)
    bpy.utils.unregister_class(ASPECT_OT_SetRatio)
    bpy.utils.unregister_class(AspectRatioSettings)
    del bpy.types.Scene.aspect_ratio_settings


if __name__ == "__main__":
    register()
